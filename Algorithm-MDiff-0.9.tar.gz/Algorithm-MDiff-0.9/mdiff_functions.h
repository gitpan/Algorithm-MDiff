#ifndef mdiff_functions_H
#define mdiff_functions_H

#include <stdio.h>

int is_mdiff(int m, char *str1, char *str2);
int    mdiff(       char *str1, char *str2);

#endif 
